package com.company;
/**
 * 
 * @author javascorp
 *
 */
import java.io.Serializable;

public class superAdmin implements Serializable {
 /**
  * esto sirve para lote vacunas
  */
 int contador=0;
 String superUsuario = "JaVacunas";
 String superContasena = "123456";
 
 superAdmin(){}
 superAdmin(String superUsuario,String superContasena){
  this.superUsuario = superUsuario;
  this.superContasena=superContasena;
 }
}