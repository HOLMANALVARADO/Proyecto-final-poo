package com.company;

import java.io.Serializable;
/**
 * 
 * @author javascorp
 *
 */
public class admin implements Serializable {
	/**
	 * Atributos
	 */
 String nombre;
 String correo;
 String usuario;
 String contasena;
 
 	/**
 	 * Metodos
 	 */
 admin(String nombre,String correo,String usuario,String contasena){
  this.nombre=nombre;
  this.correo=correo;
  this.usuario=usuario;
  this.contasena=contasena;
 }
 
 public String toString() {
  String aux = "";
  aux += nombre +"\n";
  aux += usuario+"\n";
  aux += contasena+"\n" ;
  aux += correo+"\n";
  //aux += edad;
  return aux;
 }
 
}
