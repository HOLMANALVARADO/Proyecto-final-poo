package com.company;

import javax.swing.*;
import java.io.*;
import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.util.*;
import java.util.ArrayList;
import java.util.Arrays;

import org.apache.poi.hssf.usermodel.HSSFSheet;
import org.apache.poi.hssf.usermodel.HSSFWorkbook;
import org.apache.poi.ss.usermodel.Row;
import org.apache.poi.ss.usermodel.Cell;
import org.apache.poi.ss.usermodel.Sheet;
import org.apache.poi.ss.usermodel.Workbook;
/**
 * 
 * @author javascorp
 *
 */
public class claseData implements Serializable {
	/**
	 * Atributos
	 */
 String nombre;
 String codigo;
 String facultad;
 int edad,contcomor,prio;
 String genero;
 String comor;
 String comorf;
 String vinculacion;
 String carrera;
 String dosis;
 String correo;
 usuario unUsuario;
 ArrayList<usuario> usuarios = new ArrayList();
 //usuario
 
 	/**
 	 *Metodos 
 	 */
 claseData(String nombre,String codigo,String facultad,String edad,String genero, String comor,String comorf,String vinculacion,String carrera,String dosis,String correo){
  this.nombre=nombre;
  this.codigo=codigo;
  this.facultad=facultad;
  this.edad=Integer.parseInt(edad);
  this.genero=genero;
  this.comor=comor;
  this.comorf=comorf;
  this.vinculacion=vinculacion;
  this.carrera=carrera;
  this.dosis=dosis;
  //serContador();
  recuperarUsuarios();
  cambio();
  unUsuario = new usuario(nombre,codigo,facultad,this.edad,genero,comor,comorf,vinculacion,carrera,dosis,this.contcomor,correo);
  usuarios.add(unUsuario);
  guardarUsuario();
  for(int i =0;i<usuarios.size();i++){
   System.out.println(usuarios.get(i));
  }
  //crearExcel();
 }
 
 void cambio() {
  switch (comor) {
   case "RESPIRATORIAS": {
    contcomor = contcomor + 4;
    break;
   }
   case "CARDIACAS": {
    contcomor = contcomor + 3;
    break;
   }
   case "OTRAS GRAVES": {
    contcomor = contcomor + 2;
    break;
   }
   case "OTRAS LEVES": {
    contcomor = contcomor + 1;
    break;
   }
   case "NINGUNA": {
    contcomor = contcomor + 0;
    break;
   }
  }
  switch (comorf) {
   case "RESPIRATORIAS": {
    contcomor = contcomor + 4;
    break;
   }
   case "CARDIACAS": {
    contcomor = contcomor + 3;
    break;
   }
   case "OTRAS GRAVES": {
    contcomor = contcomor + 2;
    break;
   }
   case "OTRAS LEVES": {
    contcomor = contcomor + 1;
    break;
   }
   case "NINGUNA": {
    contcomor = contcomor + 0;
    break;
   }
  }
 }
 
 superAdmin superadmin = new superAdmin();
 
 claseData(boolean d){
  if(d){
  }else{
    recuperarSuperAdmin();
   }
 }
 
 claseData(int nuevolote, boolean quitardosis){
  recuperarSuperAdmin();
  if(quitardosis == false){
   superadmin.contador = superadmin.contador + nuevolote;
  }else{
    //System.out.println(superadmin.contador);
    if(superadmin.contador==0){
     JOptionPane.showMessageDialog(null,"no hay mas vacunas");
    }
    superadmin.contador--;
   }
  guardarSuperAdmin();
 }
 
 void guardarSuperAdmin(){
  try{
   FileOutputStream archivo = new FileOutputStream(".\\src\\data\\superAdmin.data");
   ObjectOutputStream escritor = new ObjectOutputStream(archivo);
   escritor.writeObject(superadmin);
   escritor.close();
   archivo.close();
   JOptionPane.showMessageDialog(null,"datos almacenados correctamente");
  }catch (Exception e){
    e.printStackTrace();
    //JOptionPane.showMessageDialog(null,"error");
   }
 }
 
 void recuperarSuperAdmin(){
  try{
   FileInputStream archivo = new FileInputStream(".\\src\\data\\superAdmin.data");
   ObjectInputStream lector = new ObjectInputStream(archivo);
   superadmin = (superAdmin) lector.readObject();
   lector.close();
   archivo.close();
   //JOptionPane.showMessageDialog(null,"se cargaron los datos");
   }catch (Exception e){
     JOptionPane.showMessageDialog(null,"error al cargar los datos");
    }
 }
 
 void guardarUsuario(){
  try{
   FileOutputStream archivo = new FileOutputStream(".\\src\\data\\usuarios.data");
   ObjectOutputStream escritor = new ObjectOutputStream(archivo);
   escritor.writeObject(usuarios);
   escritor.close();
   archivo.close();
   JOptionPane.showMessageDialog(null,"datos almacenados correctamente");
  }catch (Exception e){
    e.printStackTrace();
     //JOptionPane.showMessageDialog(null,"error");
   }
 }
 
 void recuperarUsuarios(){
  try{
   FileInputStream archivo = new FileInputStream(".\\src\\data\\usuarios.data");
   ObjectInputStream lector = new ObjectInputStream(archivo);
   usuarios = (ArrayList<usuario>) lector.readObject();
   lector.close();
   archivo.close();
   JOptionPane.showMessageDialog(null,"se cargaron los datos");
  }catch (Exception e){
    JOptionPane.showMessageDialog(null,"error al cargar los datos");
   }
 }
 
 admin unAdmin;
 ArrayList<admin> admins = new ArrayList();
 
 claseData(String contrasena,String usuario,int a){
  recuperarSuperAdmin();
  if(usuario.equals(superadmin.superUsuario)){
   superadmin.superContasena=contrasena;
   guardarSuperAdmin();
  }else{
    recuperarAdmins();
    for(int i=0;i<admins.size();i++){
     if(usuario.equals(admins.get(i).usuario)){
      admins.get(i).contasena = contrasena;
      a=i;
      break;
     }
    }
    correoArchivo obj = new correoArchivo(admins.get(a).correo);
    guardarAdmin();
   }
 }
 
 claseData(String nombre,String correo,String contasena,String usuario){
  recuperarAdmins();
  unAdmin = new admin(nombre,correo,contasena,usuario);
  admins.add(unAdmin);
  correoArchivo cor = new correoArchivo(unAdmin.correo,unAdmin.usuario,unAdmin.contasena,1);
  guardarAdmin();
 }
 
 void guardarAdmin(){
  try{
   FileOutputStream archivo = new FileOutputStream(".\\src\\data\\admins.data");
   ObjectOutputStream escritor = new ObjectOutputStream(archivo);
   escritor.writeObject(admins);
   escritor.close();
   archivo.close();
   JOptionPane.showMessageDialog(null,"datos almacenados correctamente");
  }catch (Exception e){
    e.printStackTrace();
     //JOptionPane.showMessageDialog(null,"error");
   }
 }
 
 void recuperarAdmins(){
  try{
   FileInputStream archivo = new FileInputStream(".\\src\\data\\admins.data");
   ObjectInputStream lector = new ObjectInputStream(archivo);
   admins = (ArrayList<admin>) lector.readObject();
   lector.close();
   archivo.close();
   JOptionPane.showMessageDialog(null,"se cargaron los datos admin");
   }catch (Exception e){
     JOptionPane.showMessageDialog(null,"error al cargar los datos");
    }
 }
 
 Workbook librocomp = new HSSFWorkbook();
 Sheet hojacomp = librocomp.createSheet("Priorizacion");
 correoArchivo enviar;
 
 claseData(int xd){
  recuperarSuperAdmin();
  recuperarUsuarios();
  fecha();
  comparar();
  for (int i = 0; i < usuarios.size(); i++) {
   if (usuarios.get(i).fecha == true)
    System.out.println("si" + usuarios.get(i).nombre);
  }
  guardarUsuario();
  guardarSuperAdmin();
  recuperarUsuarios();
  for(int j=0;j<usuarios.size();j++){
   if(usuarios.get(j).fecha){
    crearTexto(j);
    enviar= new correoArchivo(usuarios.get(j).correo,usuarios.get(j).nombre,"",0);
   }
  }
 }

 void mostrar(comparaDatos[] array) {
  Date date = Calendar.getInstance().getTime();
  DateFormat dateFormat = new SimpleDateFormat("yyyy-mm-dd");
  String fecha1 = dateFormat.format(date);
  String fecha = ""+today.getTime();
  int renglon=0;
  int numCelda;
  int c=0;
  String []encabezado={"Nombre","Facultad","Edad","Nivel Prio","Fecha","Estado"};
  for(int i =0;i<(usuarios.size()+1);i++) {
   if(i==1){c=0;}
   String estado = "No hay vacuna";
   for(int a=0;a<usuarios.size();a++){
    if(array[c].nombre.equals(usuarios.get(a).nombre)){
     if(usuarios.get(a).fecha){
      estado ="ya se suministro dosis";
      break;
     }
    }
   }
   if(i>0){
    if(superadmin.contador > 0) {
     for(int a=0;a<usuarios.size();a++){
      if(array[c].nombre.equals(usuarios.get(a).nombre)){
       usuarios.get(a).fecha=true;
       usuarios.get(a).sumarDosis(fecha1,fecha);
       estado="Tiene vacuna";
       superadmin.contador--;
       break;
      }
     }
    }
   }
   String []datos={array[c].nombre , array[c].facultad , Integer.toString(array[c].edad) , Integer.toString(array[c].contcomor),fecha,estado};
   Row linea = hojacomp.createRow(renglon++);
   numCelda = 0;
   c++;
   for (int j = 0; j < 6; j++) {
    if(i==0){
     Cell celda = linea.createCell(numCelda++);
     celda.setCellValue(encabezado[j]);
    }else {
      Cell celda = linea.createCell(numCelda++);
      celda.setCellValue(datos[j]);
     }
   }
  }
  try{
   FileOutputStream out = new FileOutputStream(".\\src\\txt\\priorizacion.xls");
   librocomp.write(out);
   out.close();
   JOptionPane.showMessageDialog(null,"Se creo excel exitosamente");
  }catch (Exception e){
    e.printStackTrace();
   }
  for (int i = 0; i < array.length; i++)
   System.out.println(array[i].nombre + " " + array[i].facultad + " " + array[i].edad + " " + array[i].contcomor);
 }
 
 public void comparar() {
  comparaDatos[] test = new comparaDatos[usuarios.size()];
  for(int i=0;i<usuarios.size();i++){
   if(usuarios.get(i).fecha)
    prio = -1;
   else if(usuarios.get(i).edad >= 40 && usuarios.get(i).contcomor >= 1 && prio!=-1)
    prio = 5;
   else if (usuarios.get(i).edad < 40 && usuarios.get(i).contcomor >= 7 && prio!=-1)
    prio = 4;
   else if (usuarios.get(i).edad < 40 && usuarios.get(i).contcomor >= 5 && prio!=-1)
    prio = 3;
   else if (usuarios.get(i).edad < 40 && usuarios.get(i).contcomor >= 3 && prio!=-1)
    prio = 2;
   else if (usuarios.get(i).edad < 40 && usuarios.get(i).contcomor >= 1 && prio!=-1)
    prio = 1;
   else
    prio = 0;
   test[i] = new comparaDatos(usuarios.get(i).nombre,usuarios.get(i).genero,usuarios.get(i).facultad,usuarios.get(i).comor,usuarios.get(i).edad,prio,usuarios.get(i).contcomor);
  }
  Arrays.sort(test);
  mostrar(test);
 }
 
 Calendar today = Calendar.getInstance();
 Calendar today1 = Calendar.getInstance();
 
 void fecha(){
  today.getTime();
  today.add(Calendar.DAY_OF_MONTH, 30);
 }
 
 String nombreTexto;
 FileWriter archivo;
 //claseData(String nombre){}
 
 void crearTexto(int j){
  recuperarUsuarios();
  try{
   archivo = new FileWriter(".\\src\\txt\\carnet_"+usuarios.get(j).nombre+".txt");
   BufferedWriter escritor = new BufferedWriter(archivo);
   for(int i=0;i<usuarios.size();i++) {
	   
    /**
     * escribe los datos en el archivo
     */
    escritor.write( "CARNET DE VACUNACION"+"\n");
    escritor.write("Nombre: "+ usuarios.get(j).nombre+"\n");
    escritor.write("Codigo: "+ usuarios.get(j).codigo+"\n");
    escritor.write("Dosis a aplicar: "+ usuarios.get(j).dosis+"\n");
    escritor.write("Fecha dosis aplicada: "+usuarios.get(j).fech1+"\n");
    escritor.write("Fecha proxima vacunacion: "+usuarios.get(j).fech+"\n");
   }
   escritor.close();
   archivo.close();
   System.out.println(""+usuarios.get(j).fech1);
  }catch (IOException e){
    e.printStackTrace();
    System.out.println("f");
   }
 }

 //Workbook libro = new XSSFWorkbook();
 Workbook libro = new HSSFWorkbook();
 Sheet hoja[] = new Sheet[1];
 int contfacul;//numero de facultades
 
 claseData(){
  crearExcel();
 }
 
 void crearExcel(){
  recuperarUsuarios();
  hoja[0] = libro.createSheet("Hoja de datos");
  int renglon=0;
  int numCelda;
  int c=0;
  String []encabezado={"Codigo","Nombre","Genero","Edad","Vinculacion","Facultad","Carrera","Comorbilidad","Comorbilidad F","Dosis"};
  for(int i =0;i<(usuarios.size()+1);i++) {
   if(i==1){
    c=0;
   }
   String []datos={usuarios.get(c).codigo,usuarios.get(c).nombre,usuarios.get(c).genero,Integer.toString(usuarios.get(c).edad),usuarios.get(c).vinculacion,usuarios.get(c).facultad,usuarios.get(c).carrera,usuarios.get(c).comor,usuarios.get(c).comorf,usuarios.get(c).dosis};
   Row linea = hoja[0].createRow(renglon++);
   numCelda = 0;
   c++;
   for (int j = 0; j < 10; j++) {
    if(i==0){
     Cell celda = linea.createCell(numCelda++);
     celda.setCellValue(encabezado[j]);
    }else {
      Cell celda = linea.createCell(numCelda++);
      celda.setCellValue(datos[j]);
     }
   }
  }
  try{
   FileOutputStream out = new FileOutputStream(".\\src\\txt\\prueba.xls");
   libro.write(out);
   out.close();
   JOptionPane.showMessageDialog(null,"Se creo excel exitosamente");
  }catch (Exception e){
    e.printStackTrace();
   }
 }

 String contrasena;
 String usuario;
 boolean loginA = false;
 boolean login = false;
 
 claseData(String contrasena, String usuario){
  login = false;
  this.contrasena=contrasena;
  this.usuario=usuario;
  recuperarSuperAdmin();
  if(usuario.equals("")&& contrasena.equals("")){
   JOptionPane.showMessageDialog(null,"Usuario y contraseña correctos");
   loginA=true;
  }else{
    recuperarAdmins();
    comprobar();
   }
 }
 
 void comprobar(){
  for(int i=0;i<admins.size();i++){
   if(usuario.equals(admins.get(i).usuario)&&contrasena.equals(admins.get(i).contasena)) {
    login = true;
    JOptionPane.showMessageDialog(null, "Usuario y contraseña correctos");
   }else {
     JOptionPane.showMessageDialog(null,"Datos incorrectos");
    }
   break;
  }
 }
}