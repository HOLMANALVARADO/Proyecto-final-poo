package com.company;
/**
 * 
 * @author javascorp
 *
 */
public class Main {
 public static void main(String[] args) {
  //claseData obj = new claseData(1);
  //intento ob = new intento();
  inicioSesion obj = new inicioSesion();
 }
}