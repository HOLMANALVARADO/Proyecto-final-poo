package com.company;
/**
 * 
 * @author javascorp
 *
 */
import java.io.Serializable;

public class usuario implements Serializable {
	/**
	 * Atributos
	 */
 String nombre;
 String codigo;
 String facultad;
 int edad,contcomor;
 String genero;
 String comor;
 String comorf;
 String vinculacion;
 String carrera;
 String dosis;
 String correo;
 String fech;
 String fech1;
 boolean fecha = false;
 	/**
 	 * Metodos
 	 */
 usuario(String nombre,String codigo,String facultad,int edad,String genero, String comor,String comorf,String vinculacion,String carrera,String dosis,int contcomor,String correo){
  this.nombre=nombre;
  this.codigo=codigo;
  this.facultad=facultad;
  this.edad=edad;
  this.genero=genero;
  this.comor=comor;
  this.comorf=comorf;
  this.vinculacion=vinculacion;
  this.carrera=carrera;
  this.dosis=dosis;
  this.contcomor=contcomor;
  this.correo=correo;
 }
 
 void sumarDosis(String fecha1,String fecha){
  fech1=fecha1;
  fech=fecha;
  System.out.println(fecha1+"----"+fecha);
  switch (dosis){
   case "NINGUNA":{
    dosis ="PRIMERA";
    break;
   }
   case "PRIMERA":{
    dosis="SEGUNDA";
    break;
   }
   case "SEGUNDA":{
    dosis="TERCERA";
    break;
   }
   case "TERCERA":{
    break;
   }
  }
 }
 
 /**
  * Valores de las comorbilidades: "RESPIRATORIA 4","CARDIACAS 3","OTRAS GRAVES 2","OTRAS LEVES 1","NINGUNA 0"
  */
 public String toString() {
  String aux = "";
  aux += nombre ;
  aux += contcomor;
  //aux += codigo ;
  //aux += facultad;
  //aux += edad;
  return aux;
 }
}