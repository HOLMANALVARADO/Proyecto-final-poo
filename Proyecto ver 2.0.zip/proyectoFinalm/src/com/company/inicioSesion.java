package com.company;
/**
 * 
 * @author javascorp
 *
 */
import javax.swing.*;
import javax.swing.border.TitledBorder;
import java.awt.*;
import java.awt.event.*;
import java.util.ArrayList;

public class inicioSesion extends JFrame implements ActionListener{
	/**
	 * Atributos
	 */
 private JLabel lblUsuario;
 private JTextField txtUsuario;
 private JTextField txtCaptcha;
 private JLabel lblContrasena;
 private JTextField txtContrasena;
 private JButton btnAutenticar;
 private JButton btnCambiar;
 private JButton btnSalir;
 private String rand;
 private String []respuestaCaptcha={"qGphJD","notarobot","W68HP"};
 int ran;
 JLabel img;
 Icon imgcaptcha;
 JFrame marco,marcoSuper,marcoUsuario,marcoAdmin,marcoA,marcoCambio,marcoCU;
 boolean lifehack = false, isLifehack2=false;
 
 inicioSesion(){
	 
 	 /**
 	  * atributos de la ventana
 	  */
  marco = new JFrame();
  marco.setTitle("Autenticador de usuarios");
  marco.setSize(400, 600);
  marco.setLocationRelativeTo(null);
  //marco.getContentPane().setBackground(Color.GREEN);
  marco.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
  marco.setVisible(true);
  marco.setLayout(new GridLayout(5,0));
  
  lblUsuario = new JLabel("Nombre usuario: ", JLabel.RIGHT);
  lblUsuario.setFont(new Font(Font.SANS_SERIF, Font.BOLD, 20));
  
  txtUsuario = new JTextField(12);
  txtUsuario.setFont(new Font(Font.SANS_SERIF, Font.BOLD, 20));
  
  lblContrasena = new JLabel("Contrase�a: ", JLabel.RIGHT);
  lblContrasena.setFont(new Font(Font.SANS_SERIF, Font.BOLD, 20));
  
  txtContrasena = new JTextField(12);
  txtContrasena.setFont(new Font(Font.SANS_SERIF, Font.BOLD, 20));
  
     /**
      *  Instancia y configura los botones
      */
  btnAutenticar = new JButton("Autenticar");
  btnAutenticar.addActionListener(this);
  btnAutenticar.setBounds(180, 130, 100, 50);

  btnCambiar = new JButton("Cambiar");
  btnCambiar.addActionListener(this);
  btnCambiar.setBounds(180, 130, 100, 50);

  btnSalir = new JButton("Salir");
  btnSalir.addActionListener(this);
  btnSalir.setBounds(180, 130, 100, 50);
    
     /**
      *  Panel para los botones
      */
  JPanel panelBotones = new JPanel();
  panelBotones.setPreferredSize(new Dimension(400, 50));
  panelBotones.setLayout(new FlowLayout());
  panelBotones.add(btnAutenticar);
  panelBotones.add(btnCambiar);
  panelBotones.add(btnSalir);

     /**
      * panel para la autenticar los usuarios
      */
  JPanel panelAutenticarU = new JPanel();
  panelAutenticarU.setPreferredSize(new Dimension (450, 90));
  panelAutenticarU.add(lblUsuario);
  panelAutenticarU.add(txtUsuario);
  
     /**
      * panel para autenticar las contrasenas
      */
  JPanel panelAutenticarC = new JPanel();
  panelAutenticarC.setPreferredSize(new Dimension (450, 90));
  panelAutenticarC.add(lblContrasena);
  panelAutenticarC.add(txtContrasena);
  
  	 /**
  	  * panel para agragar todo lo anterior
  	  */
  //JPanel arriba = new JPanel();
  //arriba.setLayout(new GridLayout(2,0));
  //marco.add(arriba);
  marco.add(panelAutenticarU);
  marco.add(panelAutenticarC);
  
     /**
      *  se agrega el captcha
      */
  //JPanel captcha = new JPanel();
  //marco.add(captcha);
  //captcha.setLayout(new GridLayout(3,0));
  JPanel imagen = new JPanel();
  imagen.setBorder(new TitledBorder(BorderFactory.createEmptyBorder(),"CAPTCHA",TitledBorder.CENTER, TitledBorder.DEFAULT_POSITION ));
  img = new JLabel();
  rand();
  imagen.add(img);
  marco.add(imagen);
  JPanel btntxt = new JPanel();
  marco.add(btntxt);
  txtCaptcha = new JTextField(12);
  txtCaptcha.setFont(new Font(Font.SANS_SERIF, Font.BOLD, 20));
  btntxt.add(txtCaptcha);
  marco.add(panelBotones);
 }
 
 void rand(){
  ran = 1+(int)(Math.random()*3);
  rand = ".\\src\\img\\captcha"+ran+".jpg";
  imgcaptcha = new ImageIcon(new ImageIcon(rand).getImage().getScaledInstance(140,140,Image.SCALE_SMOOTH));
  img.setIcon(imgcaptcha);
 }

 public void actionPerformed(ActionEvent evt){
  if(evt.getSource()==btnAutenticar) {
   //if(txtCaptcha.getText().equals(respuestaCaptcha[ran-1])){
   String con = txtContrasena.getText();
   String us = txtUsuario.getText();
   claseData a = new claseData(con, us);
   if (a.loginA == true) {
    interfazsuperadmin();
    marco.setVisible(false);
   }else {
     if (a.login == true) {
      interfazAdmin(a.usuario);
      marco.setVisible(false);
     }
    }
 /*
  }else {
   rand();
   JOptionPane.showMessageDialog(null,"captcha incorrecto");
   }
 */
  }
  if(evt.getSource()==btnSalir){
   JOptionPane.showMessageDialog(null, "chao");
   System.exit(0);
  }
  if(lifehack == true){
   if(box[3].getSelectedItem().toString().equals("PROFESOR")){
    if(camb==false){
     box[4].removeAllItems();
     box[4].addItem("DE PLANTA");
     box[4].addItem("OCACIONAL");
     lbl1[4].setText("CONTRATO");
     isLifehack2 =true;
    }
   }
   if(box[3].getSelectedItem().toString().equals("ESTUDIANTE")){
    if(camb==false){
     box[4].removeAllItems();
     lbl1[4].setText("CARRERA");
     isLifehack2=false;
    }
   }
  }
 }
 
 JComboBox menu;
 JButton user = new JButton();
 Icon userimg,adminimg,julio;
 JButton adminbtn = new JButton();
 claseData d = new claseData(false);
 JLabel dosis = new JLabel("Dosis actuales: "+d.superadmin.contador);
 
 void interfazsuperadmin(){
  marcoSuper = new JFrame();
  marcoSuper.setTitle("SUPER ADMIN");
  marcoSuper.setSize(400, 600);
  marcoSuper.setLocationRelativeTo(null);
  marcoSuper.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
  marcoSuper.setVisible(true);
  marcoSuper.setLayout(new GridLayout(3,0));
  JPanel arriba = new JPanel();
  arriba.setLayout(new FlowLayout());
  String []s ={"Cerrar Sesion","Priorizacion","Modificar datos","Cambiar contrase�a","Generar informe","Suministrar Dosis"};
  menu = new JComboBox(s);
  menu.setPreferredSize(new Dimension(150,20));
  arriba.add(menu);
  arriba.add(dosis);
  marcoSuper.add(arriba);
  JPanel centro = new JPanel();
  centro.setLayout(new GridLayout(0,2));
  JPanel centro1 = new JPanel();
  centro1.setLayout(new FlowLayout());
  userimg = new ImageIcon(new ImageIcon(".\\src\\img\\user.png").getImage().getScaledInstance(140,140,Image.SCALE_SMOOTH));
  user.setIcon(userimg);
  JLabel eti = new JLabel("CREAR USUARIO");
  //user.setPreferredSize(new Dimension(150,20));
  centro1.add(eti);
  centro1.add(user);
  centro.add(centro1);
  JPanel centro2 = new JPanel();
  centro1.setLayout(new FlowLayout());
  adminimg = new ImageIcon(new ImageIcon(".\\src\\img\\admin.jpg").getImage().getScaledInstance(140,140,Image.SCALE_SMOOTH));
  adminbtn.setIcon(adminimg);
  JLabel eti2 = new JLabel("CREAR ADMIN");
  //user.setPreferredSize(new Dimension(150,20));
  centro1.add(eti);
  centro1.add(user);
  centro2.add(eti2);
  centro2.add(adminbtn);
  centro.add(centro2);
  centro.add(centro1);
  marcoSuper.add(centro);
  JPanel juliop = new JPanel();
  JLabel jul = new JLabel();
  julio = new ImageIcon(new ImageIcon(".\\src\\img\\A.jpg").getImage().getScaledInstance(300,200,Image.SCALE_SMOOTH));
  jul.setIcon(julio);
  juliop.add(jul);
  marcoSuper.add(juliop);
  menu.addActionListener(this::menuActionPerformed);
  user.addActionListener(this:: userActionPerformed);
  adminbtn.addActionListener(this:: adminbtnActionPerformed);
 }
 
 private void userActionPerformed(ActionEvent e){
  interfazCrearPersona(false,0);
 }
 
 private void adminbtnActionPerformed(ActionEvent e){
  interfazCrearAdmin();
 }
 
 private void menuActionPerformed(ActionEvent e){
  String escoger = menu.getSelectedItem().toString();
  switch (escoger){
   case "Cerrar Sesion":{
    d.recuperarSuperAdmin();
    dosis.setText("Dosis actuales: "+d.superadmin.contador);
    marcoSuper.setVisible(false);
    marco.setVisible(true);
    txtContrasena.setText("");
    txtUsuario.setText("");
    break;
   }
   case"Priorizacion":{
    claseData ob = new claseData(0);
    d.recuperarSuperAdmin();
    dosis.setText("Dosis actuales: "+d.superadmin.contador);
    break;
   }
   case"Modificar datos":{
    cambio.recuperarUsuarios();
    JTextField num = new JTextField(12);
    Object ms[]={"digite el Codigo para cambiar datos:",num};
    String t;
    JOptionPane.showMessageDialog(null, ms,"Cambio de datos",JOptionPane.QUESTION_MESSAGE);
    t =num.getText();
    if(t.equals("")){
     JOptionPane.showMessageDialog(null,"llene los campos");
    }
    for(int j=0;j<cambio.usuarios.size();j++){
     if(t.equals(cambio.usuarios.get(j).codigo)){
      interfazCrearPersona(true,j);
     }else{
       JOptionPane.showMessageDialog(null,"No se encontro la persona");
      }
     break;
    }
    break;
   }
   case"Cambiar contrase�a":{
    admin = "JaVacunas";
    cambioContrasena("JaVacunas");
    break;
   }
   case "Generar informe":{
    claseData ob = new claseData();
    break;
   }
   case"Suministrar Dosis":{
    JTextField num = new JTextField(12);
    Object ms[]={"Vacunas a agregar",num};
    String t;
    do{
     JOptionPane.showMessageDialog(null, ms,"Suministrar Lote Vacunas",JOptionPane.QUESTION_MESSAGE);
     t =num.getText();
     if(ver(t)==false){
      JOptionPane.showMessageDialog(null,"Datos mal ingresados");
     }
    }while(ver(t)==false);
    claseData o = new claseData(Integer.parseInt(t),false);
    d.recuperarSuperAdmin();
    dosis.setText("Dosis actuales: "+d.superadmin.contador);
    break;
   }
  }
 }

 JTextField txtA[] = new JTextField[4];
 JPanel pnlA[]= new JPanel[4];
 JLabel lblA[]= new JLabel[4];
 
 void interfazCrearAdmin(){
  marcoA = new JFrame();
  marcoA.setTitle("ADMIN");
  marcoA.setSize(400, 300);
  marcoA.setLocationRelativeTo(null);
  marcoA.setVisible(true);
  marcoA.setLayout(new BorderLayout());
  String []A={"NOMBRE","CORREO","USUARIO","CONTRASE�A"};
  JLabel arriba = new JLabel();
  arriba.setLayout(new FlowLayout());
  marcoA.add(arriba,BorderLayout.CENTER);
  for(int i=0;i<4;i++){
   pnlA[i] = new JPanel();
   pnlA[i].setLayout(new FlowLayout());
   arriba.add(pnlA[i]);
   lblA[i] = new JLabel();
   lblA[i].setText(A[i]);
   pnlA[i].add(lblA[i]);
   txtA[i] = new JTextField(12);
   txtA[i].setFont(new Font(Font.SANS_SERIF, Font.BOLD, 20));
   pnlA[i].add(txtA[i]);
  }
  JPanel boton = new JPanel();
  boton.setLayout(new FlowLayout());
  //boton.setPreferredSize(new Dimension(100,20));
  boton.add(aceptarA);
  boton.add(salirA);
  marcoA.add(boton,BorderLayout.SOUTH);
  aceptarA.addActionListener(this::aceptarAActionPerformed);
  salirA.addActionListener(this::salirAActionPerformed);
 }
 
 private void aceptarAActionPerformed(ActionEvent evt){
  String []A = new String[4];
  if(txtA[0].getText().equals("") || txtA[1].getText().equals("")||txtA[2].getText().equals("") || txtA[3].getText().equals("")){
  }else{
    for(int i=0;i<4;i++){
     A[i]=txtA[i].getText();
     //System.out.println(h[i]);
    }
    claseData admin = new claseData(A[0],A[1],A[2],A[3]);
    for(int i=0;i<4;i++){
     txtA[i].setText("");
    }
   }
 }
 
 private void salirAActionPerformed(ActionEvent evt){
  marcoA.setVisible(false);
 }

 JComboBox menua;
 JButton usera = new JButton();
 Icon userimga,julioa;
 JButton aceptarA = new JButton("aceptar");
 JButton salirA = new JButton("Salir");
 String admin;
 
 void interfazAdmin(String usuario){
  admin = usuario;
  marcoAdmin = new JFrame();
  marcoAdmin.setTitle("ADMIN "+usuario);
  marcoAdmin.setSize(400, 600);
  marcoAdmin.setLocationRelativeTo(null);
  marcoAdmin.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
  marcoAdmin.setVisible(true);
  marcoAdmin.setLayout(new GridLayout(3,0));
  JPanel arriba = new JPanel();
  arriba.setLayout(new FlowLayout());
  String []s ={"Cerrar Sesion","Priorizacion","Modificar datos","Cambiar contrase�a","Generar informe"};
  menua = new JComboBox(s);
  menua.setPreferredSize(new Dimension(150,20));
  arriba.add(menua);
  arriba.add(dosis);
  marcoAdmin.add(arriba);
  JPanel centro = new JPanel();
  centro.setLayout(new FlowLayout());
  userimga = new ImageIcon(new ImageIcon(".\\src\\img\\user.png").getImage().getScaledInstance(140,140,Image.SCALE_SMOOTH));
  usera.setIcon(userimga);
  JLabel eti = new JLabel("CREAR USUARIO");
  centro.add(eti);
  centro.add(usera);
  marcoAdmin.add(centro);
  JPanel juliop = new JPanel();
  JLabel jul = new JLabel();
  julioa = new ImageIcon(new ImageIcon(".\\src\\img\\A.jpg").getImage().getScaledInstance(300,200,Image.SCALE_SMOOTH));
  jul.setIcon(julioa);
  juliop.add(jul);
  marcoAdmin.add(juliop);
  menua.addActionListener(this::menuaActionPerformed);
  usera.addActionListener(this:: useraActionPerformed);
 }
 
 private void useraActionPerformed(ActionEvent e){
  interfazCrearPersona(false,0);
 }
 
 private void menuaActionPerformed(ActionEvent e){
  String escoger = menua.getSelectedItem().toString();
  switch (escoger){
   case "Cerrar Sesion":{
    d.recuperarSuperAdmin();
    dosis.setText("Dosis actuales: "+d.superadmin.contador);
    marcoAdmin.setVisible(false);
    marco.setVisible(true);
    txtContrasena.setText("");
    txtUsuario.setText("");
    break;
   }
   case"Priorizacion":{
    claseData ob = new claseData(0);
    d.recuperarSuperAdmin();
    dosis.setText("Dosis actuales: "+d.superadmin.contador);
    break;
   }
   case"Modificar datos":{
    cambio.recuperarUsuarios();
    JTextField num = new JTextField(12);
    Object ms[]={"digite el Codigo para cambiar datos:",num};
    String t;
    JOptionPane.showMessageDialog(null, ms,"Cambio de datos",JOptionPane.QUESTION_MESSAGE);
    t =num.getText();
    if(t.equals("")){
     JOptionPane.showMessageDialog(null,"llene los campos");
    }
    for(int j=0;j<cambio.usuarios.size();j++){
     if(cambio.usuarios.get(j).codigo.equals(t)){
      interfazCrearPersona(true,j);
     }else{
       JOptionPane.showMessageDialog(null,"No se encontro la persona");
      }
     break;
    }
    break;
   }
   case"Cambiar contrasena":{
    cambioContrasena(admin);
    break;
   }
   case "Generar informe":{
    claseData ob = new claseData();
    break;
   }
  }
 }

 JButton aceptar = new JButton("aceptar");
 JButton salir = new JButton("Salir");
 JTextField txt[] = new JTextField[3];
 JPanel pnl[]= new JPanel[4];
 JLabel lbl[]= new JLabel[4];
 JComboBox fac;
 JLabel lbl1[]= new JLabel[6];
 JPanel pnl1[]= new JPanel[6];
 JComboBox box[]= new JComboBox[6];
 JTextField correo = new JTextField(12);
 claseData cambio = new claseData(true);
 boolean camb;
 int cont;
 
 void interfazCrearPersona(boolean camb, int cont){
  this.camb=camb;
  this.cont=cont;
  lifehack=true;
  
  marcoUsuario = new JFrame();
  if(camb){
   marcoUsuario.setTitle("CAMBIAR DATOS");
  }else{
    marcoUsuario.setTitle("AGREGAR UN USUARIO");
   }
  marcoUsuario.setSize(600, 600);
  marcoUsuario.setLocationRelativeTo(null);
  //marco.setResizable(false);
  //marcoUsuario.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
  marcoUsuario.setVisible(true);
  marcoUsuario.setLayout(new GridLayout(3,0));
  JPanel arriba= new JPanel();
  arriba.setLayout(new GridLayout(2,2));
  marcoUsuario.add(arriba);
  String []h = {"NOMBRE","CODIGO","EDAD"};
  String []facult ={"INGENIERIA","ARTES","MEDIO AMBIENTE","TECNOLOGICA","EDUCACION"};
  for(int i=0;i<3;i++){
   pnl[i] = new JPanel();
   pnl[i].setLayout(new FlowLayout());
   arriba.add(pnl[i]);
   lbl[i] = new JLabel();
   lbl[i].setText(h[i]);
   pnl[i].add(lbl[i]);
   txt[i] = new JTextField(12);
   txt[i].setFont(new Font(Font.SANS_SERIF, Font.BOLD, 20));
   pnl[i].add(txt[i]);
  }
  pnl[3]= new JPanel();
  arriba.add(pnl[3]);
  pnl[3].setLayout(new FlowLayout());
  pnl[3].add(lbl[3]= new JLabel("FACULTAD"));
  pnl[3].add(fac = new JComboBox(facult));
  JPanel combo = new JPanel();
  combo.setLayout(new GridLayout(2,3));
  String []s0={"GENERO","COMORBILIDAD","COMORBILIDAD FAMILIAR","VINCULACION","CARRERA","QUE DOSIS TIENE?"};
  String []s1={"MASCULINO","FEMENINO","PREFIERO NO DECIRLO","OTROS"};
  String []s2 ={"RESPIRATORIAS","CARDIACAS","OTRAS GRAVES","OTRAS LEVES","NINGUNA"};
  String []s3={"RESPIRATORIAS","CARDIACAS","OTRAS GRAVES","OTRAS LEVES","NINGUNA"};
  String []s4={"ESTUDIANTE","PROFESOR"};
  String []s5={""};
  String []s6={"NINGUNA","PRIMERA","SEGUNDA"};
  ArrayList<String[]> total =  new ArrayList<>();
  total.add(s1);total.add(s2);total.add(s3);total.add(s4);total.add(s5);total.add(s6);
  for(int j =0;j<6;j++){
   pnl1[j] = new JPanel();
   pnl1[j].setLayout(new FlowLayout());
   combo.add(pnl1[j]);
   lbl1[j]= new JLabel();
   lbl1[j].setText(s0[j]);
   box[j]= new JComboBox(total.get(j));
   box[j].setPreferredSize(new Dimension(150,20));
   pnl1[j].add(lbl1[j]);
   pnl1[j].add(box[j]);
  }
  marcoUsuario.add(combo);
  JPanel boton2 = new JPanel();
  boton2.setLayout(new GridLayout(2,0));
  JPanel boton = new JPanel();
  boton.setLayout(new FlowLayout());
  boton.setPreferredSize(new Dimension(100,20));
  correo.setText("");
  correo.setFont(new Font(Font.SANS_SERIF, Font.BOLD, 20));
  JLabel eti = new JLabel("CORREO");
  JPanel boton1 = new JPanel();
  boton1.setLayout(new FlowLayout());
  boton1.setPreferredSize(new Dimension(300,100));
  boton1.add(eti);
  boton1.add(correo);
  boton.add(boton1);
  boton.add(aceptar);
  boton.add(salir);
  boton2.add(boton1);
  boton2.add(boton);
  marcoUsuario.add(boton2);
  fac.addActionListener(this::facActionPerformed);
  aceptar.addActionListener(this::aceptarActionPerformed);
  salir.addActionListener(this::salirActionPerformed);
  box[3].addActionListener(this);
  JButton btncamb = new JButton("Seleccionar");
  JLabel eticamb = new JLabel("Cambio de vinculacion?");
  btncamb.addActionListener(this::btncambActionPerformed);
  if(camb){
   correo.setText(cambio.usuarios.get(cont).correo);
   txt[0].setText(cambio.usuarios.get(cont).nombre);
   txt[1].setText(cambio.usuarios.get(cont).codigo);
   txt[2].setText(""+cambio.usuarios.get(cont).edad);
   fac.setSelectedItem(cambio.usuarios.get(cont).facultad);
   box[0].setSelectedItem(cambio.usuarios.get(cont).genero);
   box[1].setSelectedItem(cambio.usuarios.get(cont).comor);
   box[2].setSelectedItem(cambio.usuarios.get(cont).comorf);
   box[3].setSelectedItem(cambio.usuarios.get(cont).vinculacion);
   box[4].setSelectedItem(cambio.usuarios.get(cont).carrera);
   box[5].setSelectedItem(cambio.usuarios.get(cont).dosis);
   boton.add(eticamb);
   boton.add(btncamb);
  }
 }
 
 private void btncambActionPerformed(ActionEvent evt){
  camb = false;
 }
 
 String []h = new String[4];
 String []b= new String[6];
 
 private void facActionPerformed(ActionEvent evt){
  if(isLifehack2 == false){
   String f=fac.getSelectedItem().toString();
   switch (f){
    case"INGENIERIA":{
     box[4].removeAllItems();
     String []ing={"INDUSTRIAL","SISTEMAS","ELECTRICA","ELECTRONICA","CATASTRAL"};
     for(int i=0;i<5;i++){
      box[4].addItem(ing[i]);
     }
     break;
    }
    case"ARTES":{
     box[4].removeAllItems();
     String []art={"DANZARIO","ESCENICAS","MUSICALES","PLASTICAS Y VISUALES","RECONOCIMIENTO"};
     for(int i=0;i<5;i++){
      box[4].addItem(art[i]);
     }
     break;
    }
    case"MEDIO AMBIENTE":{
     box[4].removeAllItems();
     String []med={"TEC GESTION AMBIENTAL","TEC SANEAMIENTO","TEC LEVANTAMIENTOS","ADMIN.AMBIENTAL","ADMIN.DEPORTIVA","ING.AMBIENTAL","ING.FORESTAL","ING.SANITARIA","ING.TOPOGRAFICA"};
     break;
    }
    case"TECNOLOGICA":{
     box[4].removeAllItems();
     String []tec={"tec"};
     break;
    }
    case"EDUCACION":{
     box[4].removeAllItems();
     String []ed={"ed"};
     break;
    }
   }
  }
 }
 
 private void aceptarActionPerformed(ActionEvent evt){
  if(ver(txt[2].getText())==false){
   JOptionPane.showMessageDialog(null,"edad mal digitada");
  }else if(txt[0].getText().equals("") || txt[1].getText().equals("")||correo.getText().equals("")){
    JOptionPane.showMessageDialog(null,"llene los campos");
   }else{
     for(int i=0;i<3;i++){
      h[i]=txt[i].getText();
      //System.out.println(h[i]);
     }
     for(int j=0;j<6;j++){
      b[j]= box[j].getSelectedItem().toString();
      //System.out.println(b[j]);
     }
     if(camb){
      cambio.usuarios.get(cont).nombre=h[0];
      cambio.usuarios.get(cont).codigo=h[1];
      cambio.usuarios.get(cont).facultad=fac.getSelectedItem().toString();
      cambio.usuarios.get(cont).edad=Integer.parseInt(h[2]);
      cambio.usuarios.get(cont).genero=b[0];
      cambio.usuarios.get(cont).comor=b[1];
      cambio.usuarios.get(cont).comorf=b[2];
      cambio.usuarios.get(cont).vinculacion=b[3];
      cambio.usuarios.get(cont).carrera=b[4];
      cambio.usuarios.get(cont).dosis=b[5];
      correo.getText();
      cambio.guardarUsuario();
      marcoUsuario.setVisible(false);
     }else{
       claseData usu= new claseData(h[0],h[1],fac.getSelectedItem().toString(),h[2], b[0], b[1], b[2],b[3], b[4],b[5],correo.getText());
      }
     for(int i=0;i<3;i++){
      txt[i].setText("");
     }
     correo.setText("");
    }
 }
 
 private void salirActionPerformed(ActionEvent evt){
  marcoUsuario.setVisible(false);
 }
 
 /*
    String h captura lo de campos de texto
    string b captura lo del combobox
    h[0] = nombre , h[1]=codigo, h[2]=facultad , h[3]=edad
    b[0]=GENERO,b[1]=COMORBILIDAD",b[2]=COMORBILIDAD FAMILIAR","b[3]=VINCULACION","b[4]=CARRERA","b[5]=DOSIS"
    ya se captura toda la info, al dar en el boton
 */

 boolean ver (String b){
  try{
   int c = Integer.parseInt(b);
   return true;
  }catch(NumberFormatException nfe){
    return false;
   }
 }

 JTextField tetx = new JTextField(12);
 JTextField tetx1 = new JTextField(12);
 
 void cambioContrasena(String admin){
  marcoCambio = new JFrame();
  marcoCambio.setTitle("CAMBIO CONTRASE�A");
  marcoCambio.setSize(600, 600);
  marcoCambio.setLocationRelativeTo(null);
  //marco.setResizable(false);
  //marcoUsuario.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
  marcoCambio.setVisible(true);
  marcoCambio.setLayout(new FlowLayout());
  JPanel arriba = new JPanel();
  arriba.setLayout(new FlowLayout());
  marcoCambio.add(arriba);
  JLabel eti = new JLabel("Digite su nueva contrase�a");
  tetx.setFont(new Font(Font.SANS_SERIF, Font.BOLD, 20));
  arriba.add(eti);
  arriba.add(tetx);
  JPanel abajo = new JPanel();
  abajo.setLayout(new FlowLayout());
  marcoCambio.add(abajo);
  JLabel eti1 = new JLabel("Digite denuevo contrase�a");
  tetx1.setFont(new Font(Font.SANS_SERIF, Font.BOLD, 20));
  abajo.add(eti1);
  abajo.add(tetx1);
  JButton ets = new JButton("ACEPTAR");
  ets.addActionListener(this :: etsActionPerformed);
  JButton etsal = new JButton("SALIR");
  etsal.addActionListener(this :: etsalActionPerformed);
  JPanel masabajo = new JPanel();
  masabajo.setLayout(new FlowLayout());
  masabajo.add(ets);
  masabajo.add(etsal);
  marcoCambio.add(masabajo);
 }
 
 private void etsActionPerformed(ActionEvent evt){
  if(tetx.getText().equals(tetx1.getText())){
   marcoCambio.setVisible(false);
   JOptionPane.showMessageDialog(null,"Cambio exitoso");
   claseData cambio = new claseData(tetx.getText(),admin,0);
  }else {
    JOptionPane.showMessageDialog(null,"Contrase�as no coinciden");
   }
 }
 
 private void etsalActionPerformed(ActionEvent evt){
  marcoCambio.setVisible(false);
 }
}