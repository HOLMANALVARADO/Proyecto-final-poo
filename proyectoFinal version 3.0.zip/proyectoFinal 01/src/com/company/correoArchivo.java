package com.company;
/**
 *
 * @author javascorp
 *
 */
import javax.activation.DataHandler;
import javax.activation.FileDataSource;
import javax.mail.*;
import javax.mail.internet.InternetAddress;
import javax.mail.internet.MimeBodyPart;
import javax.mail.internet.MimeMessage;
import javax.mail.internet.MimeMultipart;
import javax.swing.*;
import java.util.Properties;

public class correoArchivo {

    /**
     * Atributos
     */
    String correo;
    String usuario;
    String contrasena1;
    int confirmar;

    /**
     * Metodos
     */
    correoArchivo(String correo,String usuario,String contrasena, int confirmar) {
        this.correo=correo;
        this.usuario=usuario;
        this.contrasena1=contrasena;
        this.confirmar=confirmar;
        enviarArchivo();
    }

    void enviarArchivo() {
        Properties propiedad = new Properties();
        propiedad.setProperty("mail.smtp.host", "smtp.gmail.com");
        propiedad.setProperty("mail.smtp.starttls.enable", "true");
        propiedad.setProperty("mail.smtp.port", "587");
        propiedad.setProperty("mail.smtp.user", "javacunascorpsas@gmail.com");
        propiedad.setProperty("mail.smtp.auth", "true");
        String destinatario = correo;
        Session sesion = Session.getDefaultInstance(propiedad);
        String correoEnvia = "javacunascorpsas@gmail.com";
        String contrasena = "jaVacunate2021";
        if(confirmar==1){
            String asunto = "ERES UN NUEVO ADMIN";
        }
        String asunto = "CARNET";
        //String mensaje = "funciona";

        BodyPart adjunto = new MimeBodyPart();
        MimeMultipart multi = new MimeMultipart();
        try {
            if(confirmar==1){
                adjunto.setDataHandler(new DataHandler(new FileDataSource(".\\src\\img\\admin.jpeg")));
                adjunto.setFileName("AHORA ERES ADMIN");
            }else{
                adjunto.setDataHandler(new DataHandler(new FileDataSource(".\\src\\txt\\carnet_"+usuario+".txt")));
                adjunto.setFileName("CARNET");
            }
            multi.addBodyPart(adjunto);
        } catch (MessagingException e) {
            e.printStackTrace();
        }
        BodyPart texto = new MimeBodyPart();
        BodyPart texto1 = new MimeBodyPart();
        BodyPart texto2 = new MimeBodyPart();
        try {
            if(confirmar == 1){
                texto.setText("Usuario: "+ usuario+"\n");
                texto1.setText("contraseña: "+ contrasena1+"\n");
                texto2.setText("Por favor cambie la contraseña"+"\n");
                multi.addBodyPart(texto);
                multi.addBodyPart(texto1);
                multi.addBodyPart(texto2);
            }else{
                texto.setText("Su carnet de vacunacion"+"\n");
                multi.addBodyPart(texto);
            }
        } catch (MessagingException e) {
            e.printStackTrace();
        }
        MimeMessage mail = new MimeMessage(sesion);
        try {
            mail.setFrom(new InternetAddress(correoEnvia));
            mail.addRecipient(Message.RecipientType.TO, new InternetAddress(destinatario));
            mail.setSubject(asunto);
            mail.setContent(multi);
            //mail.setText(mensaje);

            Transport transporte = sesion.getTransport("smtp");
            transporte.connect(correoEnvia, contrasena);
            //for(int i = 0;i<20;i++){
            transporte.sendMessage(mail, mail.getAllRecipients());
            //}
            transporte.close();

            System.out.println("se envio a " + destinatario);
        } catch (SendFailedException ev) {
            JOptionPane.showMessageDialog(null, "correo invalido");
        } catch (MessagingException e) {
            e.printStackTrace();
            JOptionPane.showMessageDialog(null, "f no se pudo");
        }
    }

    correoArchivo(String correo){
        String asunto = "Cambio contraseña";
        String mensaje= "Su contraseña ha sido cambiada exitosamente";
        enviar(asunto,mensaje,correo);
    }

    void enviar(String asunto1,String mensaje1,String correo){
        Properties propiedad = new Properties();
        propiedad.setProperty("mail.smtp.host", "smtp.gmail.com");
        propiedad.setProperty("mail.smtp.starttls.enable", "true");
        propiedad.setProperty("mail.smtp.port", "587");
        propiedad.setProperty("mail.smtp.user", "javacunascorpsas@gmail.com");
        propiedad.setProperty("mail.smtp.auth", "true");

        Session sesion = Session.getDefaultInstance(propiedad);

        String correoEnvia = "javacunascorpsas@gmail.com";
        String contrasena = "jaVacunate2021";
        String destinatario=correo;
        String asunto = asunto1;
        String mensaje = mensaje1;
        MimeMessage mail = new MimeMessage(sesion);
        try {
            mail.setFrom(new InternetAddress(correoEnvia));
            mail.addRecipient(Message.RecipientType.TO, new InternetAddress(destinatario));
            mail.setSubject(asunto);
            mail.setText(mensaje);

            Transport transporte = sesion.getTransport("smtp");
            transporte.connect(correoEnvia, contrasena);
            transporte.sendMessage(mail, mail.getRecipients(Message.RecipientType.TO));
            transporte.close();

            System.out.println("se envio a "+destinatario);
        } catch (MessagingException e) {
            e.printStackTrace();
            JOptionPane.showMessageDialog(null,"f no se pudo");
        }
    }
}