package com.company;
/**
 *
 * @author javascorp
 *
 */
public class comparaDatos implements Comparable<comparaDatos> {
    /**
     * Atrubutos
     */
    public String nombre, genero, facultad, comor;
    public int edad, contcom,contcomor;

    /**
     * Metodos
     */
    public comparaDatos(String nombre, String genero, String facultad, String comor, int edad, int contcom,int contcomor) {
        this.nombre = nombre;
        this.genero = genero;
        this.facultad = facultad;
        this.comor = comor;
        this.edad = edad;
        this.contcom = contcom;
        this.contcomor = contcomor;
    }

    /**
     *  verificar los valores de comorbilidad y ordenarlos
     */
    public int compareTo(comparaDatos e) {
        if(contcom>e.contcom)
            return -1;
        if (contcom<e.contcom)
            return 1;
        return 0;

        /*
        if (contcom > e.contcom)
            return -1;
        if (contcom < e.contcom)
            return 1;
        if (edad < e.edad)
            return 1;
        if (edad > e.edad)
            return -1;
        return 0;
         */

    }
}