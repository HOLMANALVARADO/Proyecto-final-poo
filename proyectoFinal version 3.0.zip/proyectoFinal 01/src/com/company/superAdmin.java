package com.company;
/**
 *
 * @author javascorp
 *
 */
import java.io.Serializable;

public class superAdmin implements Serializable {
    /**
     * esto funciona para lote vacunas
     * Atributos
     */
    int contador=0;
    String superUsuario = "JaVacunas";
    String superContasena = "123456";

    /**
     * Metodos
     */
    superAdmin(){}

    superAdmin(String superUsuario,String superContasena){
        this.superUsuario = superUsuario;
        this.superContasena=superContasena;
    }
}
